#!/bin/bash

#JAVA_HOME=/home/mapeiyu/Tools/jdk/jdk1.8.0_102/

java -jar /usr/local/bin/jd-gui/jd-gui-1.4.0.jar
